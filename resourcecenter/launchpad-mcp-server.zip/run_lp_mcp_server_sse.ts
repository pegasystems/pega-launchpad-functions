// @ts-ignore: If you want type safety, install @types/express
import express, { Request, Response } from 'express';
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse.js';
import { server, loadToolsFromConfig } from './launchpad_mcp_server.js';
import path from 'path';
import dotenv from 'dotenv';
import { randomUUID } from 'crypto';

const log = {
  info: (message: string) => console.error('INFO: ' + message),
  error: (message: string) => console.error('ERROR: ' + message)
};

function loadEnvFromPath(envPath: string) {
  const result = dotenv.config({ path: envPath });
  if (result.error) {
    log.error(`Error loading .env file from ${envPath}: ${result.error}`);
    throw result.error;
  }
  if (!result.parsed) {
    throw new Error(`Failed to parse environment variables from ${envPath}`);
  }
  log.info(`Loaded environment variables from ${envPath}`);
  return result.parsed;
}

async function main() {
  try {
    const configPath = process.argv[2] || path.join(process.cwd(), 'config', 'tools.yaml');
    const envFilePath = process.argv[3] || path.join(process.cwd(), '.env');
    const port = process.env.PORT ? parseInt(process.env.PORT) : 3000;

    // Load environment variables
    const env = loadEnvFromPath(envFilePath);
    const requiredEnvVars = ['ACCESS_TOKEN_URL', 'CLIENT_ID', 'CLIENT_SECRET'];
    for (const envVar of requiredEnvVars) {
      if (!env[envVar]) {
        throw new Error(`${envVar} environment variable is required`);
      }
    }
    process.env.ACCESS_TOKEN_URL = env.ACCESS_TOKEN_URL!;
    process.env.CLIENT_ID = env.CLIENT_ID!;
    process.env.CLIENT_SECRET = env.CLIENT_SECRET!;

    await loadToolsFromConfig(configPath);

    const app = express();
    app.use(express.json());

    // Store active transports by session
    let transport: SSEServerTransport | null = null;


    // SSE endpoint
    app.get('/sse', (req: Request, res: Response) => {
      console.log('sse');
      // Generate a session id for this connection
      const sessionId = randomUUID();
      // Create a new transport for this connection
      transport = new SSEServerTransport('/messages', res);
      // Associate the sessionId with the transport
      server.connect(transport);

      res.on('close', () => {
      });
    });

    // Message POST endpoint
    app.post('/messages', (req: Request, res: Response) => {
      console.log('messages');
      const sessionId = req.headers['x-session-id'] as string;
      if (!transport) {
        res.status(400).json({ error: 'Invalid or missing session ID' });
        return;
      }
      if (transport.onmessage) {
        transport.onmessage(req.body);
      }
      res.status(200).json({ ok: true });
    });

    app.listen(port, () => {
      log.info(`LaunchPad Dynamic MCP Server running with SSE on port ${port}`);
    });
  } catch (error) {
    log.error(`Error during server initialization: ${error}`);
    process.exit(1);
  }
}

main().catch((error) => {
  log.error(`Fatal error in main(): ${error}`);
  process.exit(1);
}); 