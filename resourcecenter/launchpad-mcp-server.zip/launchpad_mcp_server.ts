import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import axios from 'axios';
import fs from 'fs/promises';
import path from 'path';
import yaml from 'js-yaml';
import { getAuthToken } from "./utils/auth.js";

const log = {
  info: (message: string) => console.error("INFO: " + message),
  error: (message: string) => console.error("ERROR: " + message)
};

export { log };

// Define the types for our tool configurations
interface ToolParameter {
  name: string;
  type: 'string' | 'number' | 'boolean';
  description: string;
  required: boolean;
}

interface ToolConfig {
  name: string;
  description: string;
  type: 'DataView' | 'CaseCreate';
  endpoint: string;
  parameters: ToolParameter[];
  fields: string[];
}

interface ToolsConfig {
  tools: ToolConfig[];
}

export const server = new McpServer({
  name: "Pega LaunchPad Dynamic Server",
  version: "1.0.0",
});



// Function to create a Zod schema from the tool parameters
function createZodSchema(parameters: ToolParameter[]) {
  const schemaObj: Record<string, any> = {};
  
  for (const param of parameters) {
    let zodType;
    
    switch (param.type) {
      case 'string':
        zodType = z.string();
        break;
      case 'number':
        zodType = z.number();
        break;
      case 'boolean':
        zodType = z.boolean();
        break;
      default:
        zodType = z.string();
    }
    
    // Add description
    zodType = zodType.describe(param.description);
    
    // Handle optional parameters
    if (!param.required) {
      zodType = zodType.optional();
    }
    
    schemaObj[param.name] = zodType;
  }
  
  return schemaObj;
}

// Function to execute a DataView API call
async function executeDataViewCall(endpoint: string, params: Record<string, any>) {
  // Environment variables
  const ACCESS_TOKEN_URL = process.env.ACCESS_TOKEN_URL;
  const CLIENT_ID = process.env.CLIENT_ID;
  const CLIENT_SECRET = process.env.CLIENT_SECRET;

  // Validate required environment variables
  if (!ACCESS_TOKEN_URL || !CLIENT_ID || !CLIENT_SECRET) {
    throw new Error('Required environment variables are not set');
  }

  try {
    // Get auth token
    const tokenData = await getAuthToken(
      ACCESS_TOKEN_URL as string,
      CLIENT_ID as string,
      CLIENT_SECRET as string
    );
    
    // Set up headers
    const headers = {
      'Authorization': `${tokenData.token_type} ${tokenData.access_token}`,
      'Content-Type': 'application/json'
    };
    
    // Prepare the request body with parameters
    const requestBody = params ? params : {};
    
    // Make the API call
    const response = await axios.post(endpoint, requestBody, { headers });
    
    return response.data.data;
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      throw new Error(`API call failed (client_id: ${CLIENT_ID}): ${error.response.status} - ${JSON.stringify(error.response.data)}`);
    }
    throw new Error(`API call failed (client_id: ${CLIENT_ID}): ${error}`);
  }
}

// Function to execute a CaseCreate API call
async function executeCaseCreateCall(endpoint: string, params: Record<string, any>) {
  // Environment variables
  const ACCESS_TOKEN_URL = process.env.ACCESS_TOKEN_URL;
  const CLIENT_ID = process.env.CLIENT_ID;
  const CLIENT_SECRET = process.env.CLIENT_SECRET;
  
  try {
    // Get auth token
    const tokenData = await getAuthToken(ACCESS_TOKEN_URL as string, CLIENT_ID as string, CLIENT_SECRET as string);
    
    // Set up headers
    const headers = {
      'Authorization': `${tokenData.token_type} ${tokenData.access_token}`,
      'Content-Type': 'application/json'
    };
    
    // Make the API call
    const response = await axios.post(endpoint, params, { headers });
    
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      throw new Error(`API call failed (client_id: ${CLIENT_ID}): ${error.response.status} - ${JSON.stringify(error.response.data)}`);
    }
    throw new Error(`API call failed (client_id: ${CLIENT_ID}): ${CLIENT_SECRET}): ${error}`);
  }
}

// Function to construct a query body from fields
function constructQueryBody(fields: string[]) {
  return {
    query: {
      select: fields.map(field => ({ field }))
    }
  };
}

// Function to load and register tools from YAML configuration
export async function loadToolsFromConfig(configPath: string) {
  try {
    // Read and parse the YAML file
    const fileContent = await fs.readFile(path.resolve(configPath), 'utf8');
    const config = yaml.load(fileContent) as ToolsConfig;
    
    // Register each tool defined in the config
    for (const toolConfig of config.tools) {
      const zodSchema = createZodSchema(toolConfig.parameters);
      
      // Construct the query body using fields specific to each tool
      const queryBody = constructQueryBody(toolConfig.fields);
      
      // Register the tool with the MCP server
      server.tool(
        toolConfig.name,
        toolConfig.description,
        zodSchema,
        async (params) => {
          let result;
          
          // Execute the appropriate API call based on tool type
          if (toolConfig.type === 'DataView') {
            result = await executeDataViewCall(toolConfig.endpoint, { dataViewParameters: params, query: queryBody.query });
          } else if (toolConfig.type === 'CaseCreate') {
            result = await executeCaseCreateCall(toolConfig.endpoint, params);
          } else {
            throw new Error(`Unsupported tool type: ${toolConfig.type}`);
          }
          
          // Format the result for the MCP response
          return {
            content: Array.isArray(result) 
              ? result.map(item => ({
                  type: "text",
                  text: `${JSON.stringify(item, null, 2)}`
                }))
              : [{
                  type: "text",
                  text: `${JSON.stringify(result, null, 2)}`
                }]
          };
        }
      );
      
      log.info(`Registered tool: ${toolConfig.name}`);
    }
    
    log.info('All tools registered successfully');
  } catch (error) {
    log.error(`Error loading tools from configuration: ${error}`);
    throw error;
  }
}

