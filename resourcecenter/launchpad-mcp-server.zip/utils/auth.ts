import axios from 'axios';

/**
 * Get an OAuth2 access token using client credentials grant type
 * 
 * @param accessTokenUrl - The URL endpoint for requesting access tokens
 * @param clientId - The OAuth2 client ID
 * @param clientSecret - The OAuth2 client secret
 * @returns The access token object containing token, expiry and other details
 */
export async function getAuthToken(
  accessTokenUrl: string,
  clientId: string,
  clientSecret: string
): Promise<{
  access_token: string;
  token_type: string;
  expires_in?: number;
  [key: string]: any;
}> {
  try {
    // Prepare the request body using client credentials grant
    const params = new URLSearchParams();
    params.append('grant_type', 'client_credentials');
    params.append('client_id', clientId);
    params.append('client_secret', clientSecret);

    // Set request headers
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
    };

    // Make the POST request to the token endpoint
    const response = await axios.post(accessTokenUrl, params, { headers });
    
    // Return the token response data
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      throw new Error(`Failed to get auth token ${accessTokenUrl}: ${error.response.status} - ${JSON.stringify(error.response.data)}`);
    }
    throw new Error(`Failed to get auth token ${accessTokenUrl}: ${error}`);
  }
}

/**
 * Get an authorization header with the bearer token
 * 
 * @param accessTokenUrl - The URL endpoint for requesting access tokens
 * @param clientId - The OAuth2 client ID
 * @param clientSecret - The OAuth2 client secret
 * @returns An authorization header object with the bearer token
 */
export async function getAuthorizationHeader(
  accessTokenUrl: string,
  clientId: string,
  clientSecret: string
): Promise<{ Authorization: string }> {
  const tokenResponse = await getAuthToken(accessTokenUrl, clientId, clientSecret);
  return {
    Authorization: `${tokenResponse.token_type} ${tokenResponse.access_token}`
  };
} 