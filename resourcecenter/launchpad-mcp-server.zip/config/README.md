# Dynamic MCP Tools Configuration

This directory contains YAML configuration files for the dynamic MCP server.

## Format

The `tools.yaml` file defines the tools that will be available through the MCP server. Here's the structure:

```yaml
tools:
  - name: toolName
    description: Description of what the tool does
    type: DataView | CaseCreate
    endpoint: https://api-endpoint-url
    parameters:
      - name: paramName
        type: string | number | boolean
        description: Description of the parameter
        required: true | false
```

## Tool Types

- `DataView`: For retrieving data from Pega DataView endpoints
- `CaseCreate`: For creating cases through Pega API endpoints

## Endpoints

For DataView type endpoint the endpoints will look like:
https://subscriber-app-domain/dx/api/application/v2/data_views/NameOfDataView

For CaseCreate type endpoints the endpoints will look like:



## Parameters

Each parameter must include:
- `name`: The parameter name used in API calls
- `type`: The data type (string, number, or boolean)
- `description`: A clear description of what the parameter is for
- `required`: Whether the parameter is required (true) or optional (false)

## Adding New Tools

To add a new tool:

1. Edit the `tools.yaml` file
2. Add a new entry under the `tools` array
3. Define all required properties (name, description, type, endpoint, parameters)
4. Restart the MCP server

The server will automatically load all tools defined in the configuration file at startup. 