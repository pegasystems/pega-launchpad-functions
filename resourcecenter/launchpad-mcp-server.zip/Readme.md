# Pega LaunchPad MCP Server

A [Model Context Protocol, MCP server implementation](https://modelcontextprotocol.io/introduction) that integrates with Pega LaunchPad applications, enabling natural language interactions with your Launchpad applications and data. This server allows LLMs and AI Agents to query, modify, and manage your Launchpad resources using everyday language.

This server is meant to be a reference implementation for you to modify to meet your specific needs.

## Features

- **Dynamic Tool Configuration**: Configure data vew and case DX APIs using simple YAML configuration.
- **OAuth2 Authentication**: Secure integration with Pega LaunchPad services
- **TypeScript Implementation**: Robust type safety and modern development experience
- **Supports STDIO and SSE Transports**: Run as a local stdio server or as a remote HTTP SSE server

## About This Server

MCP servers support two main connection types: STDIO and SSE (Server-Sent Events). STDIO is used for local servers, communicating via standard input/output, while SSE uses HTTP to connect to remote services, offering more flexibility and network capabilities. 

This implementation is designed and tested for both STDIO connections and SSE via HTTP endpoints.

## Installation

Note: This installation assumes you have NPM and NodeJS already installed on your local machine or the machine that will host the SSE server.

```bash
# Clone the repository
git clone [your-repository-url]

# Install dependencies
npm install

# Build
npm run build
```

## Configuration

### Environment Variables

Create a `.env` file in the project root with the following variables as setup in your subscriber oAuth2 registration in Launchpad:

```env
ACCESS_TOKEN_URL=https://your-launchpad-endpoint.com/dx/uas/oauth/token
CLIENT_ID=your-client-id
CLIENT_SECRET=your-client-secret
```

### Tool Configuration

The dynamic server loads tool definitions from the `config/tools.yaml` file. See [config/README.md](config/README.md) for details on how to configure tools.

Note: this file can be placed in any directory as long as its full path is passed as the first parameter to command line.

## Running the Server

You can run the server in either STDIO or SSE mode:

### STDIO Mode (Local)

```bash
node /full/path/to/repo/build/run_lp_mcp_server.js /path/to/tools.yaml /path/to/.env
```

### SSE Mode (HTTP/Remote)

The SSE server exposes two endpoints:
- `GET /sse` — Establishes an SSE connection for receiving events
- `POST /messages` — Receives messages from the client (requires `x-session-id` header)

To run the server in SSE mode:

```bash
node /full/path/to/repo/build/run_lp_mcp_server_sse.js /path/to/tools.yaml /path/to/.env
```

You can specify the port by setting the `PORT` environment variable (default is 3000).

#### Example

```bash
PORT=4000 node /full/path/to/repo/build/run_lp_mcp_server_sse.js /path/to/tools.yaml /path/to/.env
```

### Dependency Note

SSE mode requires [express](https://expressjs.com/). This is already included in the dependencies.

## Integrating with a MCP client 

The exact steps of integrating with an MCP client or agent will depend on the client/agent framework. For STDIO, use the command above. For SSE, configure your client to connect to the `/sse` endpoint and send messages to `/messages`.

### Examples

#### Cursor

Add the following configuration to your `mcp.json` for STDIO mode:

```json
{
  "mcpServers": {
    "launchpad": {
      "command": "node",
      "args": [
        "/Users/frank/MyCode/mcp/lp-mcp-server/build/run_lp_mcp_server.js",
        "/Users/frank/MyCode/mcp/lp-mcp-server/config/tools.yaml",
        "/Users/frank/lp.env"
      ]
    }
  }
}
```

For SSE mode you generally will need to supply the url the host is running on and the port for example with cursor it might be:

```json
{
  "mcpServers": {
    "lp-sse": {
      "url": "http://localhost:3000/sse"
    }
  }
}
```

## Troubleshooting

1. **Authentication Issues**
   - Verify your environment variables are correctly set
   - Check the OAuth2 token endpoint accessibility
   - Ensure client credentials are valid

2. **Tool Configuration**
   - Validate YAML syntax in tool definitions
   - Check tool permissions and access rights
   - Verify tool endpoints are accessible

3. **Server Issues**
   - Check server logs for error messages
   - Verify port availability
   - Ensure all required dependencies are installed

## Terms

Please note this code should not be used in production without review.  Feel free to modify it to meet your needs. It is provided as an example of how Launchpad can act as an MCP server.


