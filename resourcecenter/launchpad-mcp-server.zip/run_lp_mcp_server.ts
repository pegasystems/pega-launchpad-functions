#!/usr/bin/env node
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { server, loadToolsFromConfig } from "./launchpad_mcp_server.js";
import path from 'path';
import dotenv from 'dotenv';

const log = {
  info: (message: string) => console.error("INFO: " + message),
  error: (message: string) => console.error("ERROR: " + message)
};

// Function to load environment variables from a custom path
function loadEnvFromPath(envPath: string) {
  const result = dotenv.config({ path: envPath });
  
  if (result.error) {
    log.error(`Error loading .env file from ${envPath}: ${result.error}`);
    throw result.error;
  }
  
  if (!result.parsed) {
    throw new Error(`Failed to parse environment variables from ${envPath}`);
  }
  
  log.info(`Loaded environment variables from ${envPath}`);
  return result.parsed;
}

async function main() {
  try {
    // Get config path and env file path from command line arguments or use defaults
    const configPath = process.argv[2] || path.join(process.cwd(), 'config', 'tools.yaml');
    const envFilePath = process.argv[3] || path.join(process.cwd(), '.env');
    
    // Load environment variables
    const env = loadEnvFromPath(envFilePath);
    
    // Validate required environment variables
    const requiredEnvVars = ['ACCESS_TOKEN_URL', 'CLIENT_ID', 'CLIENT_SECRET'];
    for (const envVar of requiredEnvVars) {
      if (!env[envVar]) {
        throw new Error(`${envVar} environment variable is required`);
      }
    }

    // Set environment variables for the server
    process.env.ACCESS_TOKEN_URL = env.ACCESS_TOKEN_URL!;
    process.env.CLIENT_ID = env.CLIENT_ID!;
    process.env.CLIENT_SECRET = env.CLIENT_SECRET!;
    
    await loadToolsFromConfig(configPath);

    // Set up the transport and connect the server
    const transport = new StdioServerTransport();
    await server.connect(transport);
    //log.info("LaunchPad Dynamic MCP Server running on stdio");
  } catch (error) {
    log.error(`Error during server initialization: ${error}`);
    process.exit(1);
  }
}
  
main().catch((error) => {
  log.error(`Fatal error in main(): ${error}`);
  process.exit(1);
}); 