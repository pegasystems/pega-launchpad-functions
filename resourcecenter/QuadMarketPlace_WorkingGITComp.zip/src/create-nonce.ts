/* eslint-disable camelcase */
// @ts-ignore
if (window?.__webpack_nonce__) {
  // @ts-ignore
  __webpack_nonce__ = window.__webpack_nonce__;
}
