import requests
import datetime
import hashlib
import hmac
import base64
import json

# -------- Helper Functions -------- #
def sign(key, msg):
    return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()

def get_signature_key(secret_key, date_stamp, region, service):
    k_date = sign(('AWS4' + secret_key).encode('utf-8'), date_stamp)
    k_region = sign(k_date, region)
    k_service = sign(k_region, service)
    k_signing = sign(k_service, 'aws4_request')
    return k_signing

# -------- Core Polly Function -------- #
def polly_text_to_speech(access_key, secret_key, region, text, voice_id="Joanna"):
    service = 'polly'
    host = f'polly.{region}.amazonaws.com'
    endpoint = f'https://{host}/v1/speech'

    t = datetime.datetime.utcnow()
    amz_date = t.strftime('%Y%m%dT%H%M%SZ')
    date_stamp = t.strftime('%Y%m%d')

    canonical_uri = '/v1/speech'
    canonical_querystring = ''
    request_payload = json.dumps({
        "Text": text,
        "OutputFormat": "mp3",
        "VoiceId": voice_id
    })

    payload_hash = hashlib.sha256(request_payload.encode('utf-8')).hexdigest()
    canonical_headers = f'content-type:application/json\nhost:{host}\nx-amz-date:{amz_date}\n'
    signed_headers = 'content-type;host;x-amz-date'

    canonical_request = (
        f'POST\n{canonical_uri}\n{canonical_querystring}\n{canonical_headers}\n'
        f'{signed_headers}\n{payload_hash}'
    )

    algorithm = 'AWS4-HMAC-SHA256'
    credential_scope = f'{date_stamp}/{region}/{service}/aws4_request'
    string_to_sign = (
        f'{algorithm}\n{amz_date}\n{credential_scope}\n'
        f'{hashlib.sha256(canonical_request.encode("utf-8")).hexdigest()}'
    )

    signing_key = get_signature_key(secret_key, date_stamp, region, service)
    signature = hmac.new(signing_key, string_to_sign.encode('utf-8'), hashlib.sha256).hexdigest()

    authorization_header = (
        f'{algorithm} Credential={access_key}/{credential_scope}, '
        f'SignedHeaders={signed_headers}, Signature={signature}'
    )

    headers = {
        'Content-Type': 'application/json',
        'X-Amz-Date': amz_date,
        'Authorization': authorization_header
    }

    response = requests.post(endpoint, headers=headers, data=request_payload)

    if response.status_code == 200:
        mp3_bytes = response.content
        mp3_base64 = base64.b64encode(mp3_bytes).decode('utf-8')
        return mp3_base64
    else:
        raise Exception(f'Error {response.status_code}: {response.text}')

# -------- Lambda-style Handler -------- #
def handler(event, context=None) -> str:
    try:
        access_key = event.get('access_key')
        secret_key = event.get('secret_key')
        region = event.get('region')
        text = event.get('text')
        voice_id = event.get('voice_id', 'Joanna')  # Default to 'Joanna'

        if not all([access_key, secret_key, region, text]):
            return 'Error: Missing one or more required parameters: access_key, secret_key, region, text'

        # Directly return base64 string
        return polly_text_to_speech(access_key, secret_key, region, text, voice_id)

    except Exception as e:
        return f'Error: {str(e)}'


