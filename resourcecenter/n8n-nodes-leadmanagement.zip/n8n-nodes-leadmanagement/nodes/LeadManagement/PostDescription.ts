import type { INodeProperties } from 'n8n-workflow';

export const postOperations: INodeProperties[] = [
	{
		displayName: 'Operation',
		name: 'operation',
		type: 'options',
		noDataExpression: true,
		displayOptions: { show: { resource: ['post'] } },
		options: [
			{ name: 'Create', value: 'create', description: 'Create a new post under a campaign', action: 'Create a post' },
			{ name: 'Get Many', value: 'getMany', description: 'Get a list of posts', action: 'Get many posts' },
		],
		default: 'create',
	},
];

const postShow = (operation: string) => ({
	show: { resource: ['post'], operation: [operation] },
});

export const postFields: INodeProperties[] = [
	// -------- post:create --------
	{ displayName: 'Title', name: 'title', type: 'string', required: true, default: '', displayOptions: postShow('create') },
	{
		displayName: 'Content',
		name: 'content',
		type: 'string',
		typeOptions: { rows: 4 },
		required: true,
		default: '',
		displayOptions: postShow('create'),
	},
	{
		displayName: 'Campaign ID',
		name: 'campaignId',
		type: 'string',
		required: true,
		default: '',
		description: 'Parent campaign identifier',
		displayOptions: postShow('create'),
	},
	{ displayName: 'Scheduled Date', name: 'scheduledDate', type: 'dateTime', default: '', displayOptions: postShow('create') },
	{
		displayName: 'Platform',
		name: 'platform',
		type: 'options',
		default: 'linkedin',
		options: [
			{ name: 'Facebook', value: 'facebook' },
			{ name: 'X', value: 'x' },
			{ name: 'LinkedIn', value: 'linkedin' },
			{ name: 'Instagram', value: 'instagram' },
		],
		displayOptions: postShow('create'),
	},

	// -------- post:getMany --------
	{
		displayName: 'Limit',
		name: 'limit',
		type: 'number',
		typeOptions: { minValue: 1, maxValue: 500 },
		default: 50,
		displayOptions: postShow('getMany'),
	},
	{
		displayName: 'Filters',
		name: 'filters',
		type: 'collection',
		placeholder: 'Add Filter',
		default: {},
		displayOptions: postShow('getMany'),
		options: [
			{
				displayName: 'Campaign ID',
				name: 'campaignId',
				type: 'string',
				default: '',
				description: 'Filter posts by parent campaign ID',
			},
			{ displayName: 'Platform', name: 'platform', type: 'string', default: '' },
			{ displayName: 'Page', name: 'page', type: 'number', default: 1 },
		],
	},
];
