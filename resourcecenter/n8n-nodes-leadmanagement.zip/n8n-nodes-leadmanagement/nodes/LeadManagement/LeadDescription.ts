import type { INodeProperties } from 'n8n-workflow';

export const leadOperations: INodeProperties[] = [
	{
		displayName: 'Operation',
		name: 'operation',
		type: 'options',
		noDataExpression: true,
		displayOptions: { show: { resource: ['lead'] } },
		options: [
			{ name: 'Create', value: 'create', description: 'Create a new lead', action: 'Create a lead' },
			{ name: 'Get', value: 'get', description: 'Get a single lead by ID', action: 'Get a lead' },
			{
				name: 'Get Status',
				value: 'getStatus',
				description: 'Get only the current status of a lead',
				action: 'Get lead status',
			},
			{ name: 'Get Many', value: 'getMany', description: 'Get a list of leads', action: 'Get many leads' },
			{
				name: 'Mark Inactive',
				value: 'markInactive',
				description: 'Mark a lead as inactive',
				action: 'Mark a lead as inactive',
			},
		],
		default: 'create',
	},
];

const leadShow = (operation: string) => ({
	show: { resource: ['lead'], operation: [operation] },
});

export const leadFields: INodeProperties[] = [
	// -------- lead:create --------
	{ displayName: 'First Name', name: 'firstName', type: 'string', required: true, default: '', displayOptions: leadShow('create') },
	{ displayName: 'Last Name', name: 'lastName', type: 'string', required: true, default: '', displayOptions: leadShow('create') },
	{
		displayName: 'Email',
		name: 'email',
		type: 'string',
		placeholder: 'name@example.com',
		required: true,
		default: '',
		displayOptions: leadShow('create'),
	},
	{ displayName: 'Phone', name: 'phone', type: 'string', default: '', displayOptions: leadShow('create') },
	{ displayName: 'Company', name: 'company', type: 'string', default: '', displayOptions: leadShow('create') },
	{ displayName: 'Job Title', name: 'jobTitle', type: 'string', default: '', displayOptions: leadShow('create') },
	{
		displayName: 'Source',
		name: 'source',
		type: 'options',
		default: 'web',
		options: [
			{ name: 'Web', value: 'web' },
			{ name: 'Referral', value: 'referral' },
			{ name: 'Campaign', value: 'campaign' },
			{ name: 'Cold Call', value: 'cold_call' },
			{ name: 'Event', value: 'event' },
		],
		displayOptions: leadShow('create'),
	},
	{
		displayName: 'Rating',
		name: 'rating',
		type: 'options',
		default: 'warm',
		options: [
			{ name: 'Hot', value: 'hot' },
			{ name: 'Warm', value: 'warm' },
			{ name: 'Cold', value: 'cold' },
		],
		displayOptions: leadShow('create'),
	},
	{
		displayName: 'Notes',
		name: 'notes',
		type: 'string',
		typeOptions: { rows: 3 },
		default: '',
		displayOptions: leadShow('create'),
	},

	// -------- lead:get / lead:getStatus / lead:markInactive --------
	{
		displayName: 'Lead ID',
		name: 'leadId',
		type: 'string',
		required: true,
		default: '',
		description: 'Unique identifier of the lead',
		displayOptions: {
			show: { resource: ['lead'], operation: ['get', 'getStatus', 'markInactive'] },
		},
	},

	// -------- lead:markInactive --------
	{
		displayName: 'Inactive Reason',
		name: 'inactiveReason',
		type: 'string',
		default: '',
		description: 'Optional reason why the lead is being marked inactive',
		displayOptions: leadShow('markInactive'),
	},

	// -------- lead:getMany --------
	{
		displayName: 'Limit',
		name: 'limit',
		type: 'number',
		typeOptions: { minValue: 1, maxValue: 500 },
		default: 50,
		description: 'Max number of leads to return',
		displayOptions: leadShow('getMany'),
	},
	{
		displayName: 'Filters',
		name: 'filters',
		type: 'collection',
		placeholder: 'Add Filter',
		default: {},
		displayOptions: leadShow('getMany'),
		options: [
			{
				displayName: 'Status',
				name: 'status',
				type: 'options',
				default: 'new',
				options: [
					{ name: 'New', value: 'new' },
					{ name: 'Working', value: 'working' },
					{ name: 'Qualified', value: 'qualified' },
					{ name: 'Inactive', value: 'inactive' },
				],
			},
			{ displayName: 'Source', name: 'source', type: 'string', default: '' },
			{ displayName: 'Page', name: 'page', type: 'number', default: 1 },
		],
	},
];
