import type {
	IExecuteFunctions,
	IHookFunctions,
	ILoadOptionsFunctions,
	IHttpRequestMethods,
	IHttpRequestOptions,
	IDataObject,
	JsonObject,
} from 'n8n-workflow';
import { NodeApiError } from 'n8n-workflow';

export interface IApiResponse {
	body: IDataObject;
	headers: IDataObject;
}

function buildRequestUrl(baseUrl: string, endpoint: string): string {
	const cleanBaseUrl = baseUrl.replace(/\/$/, '');
	const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
	return `${cleanBaseUrl}${cleanEndpoint}`;
}

function sanitizeHeaders(raw: Record<string, unknown>): IDataObject {
	const safe: IDataObject = {};
	for (const [key, value] of Object.entries(raw)) {
		if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
			safe[key] = value;
		} else if (Array.isArray(value)) {
			safe[key] = value.join(', ');
		}
	}
	return safe;
}

function sanitizeBody(response: Record<string, unknown>): IDataObject {
	const { body } = response;
	if (body !== undefined && body !== null && typeof body === 'object') {
		return body as IDataObject;
	}
	if (typeof body === 'string') {
		try {
			return JSON.parse(body) as IDataObject;
		} catch {
			return { rawBody: body } as IDataObject;
		}
	}
	if (body !== undefined && body !== null) {
		return { value: body } as IDataObject;
	}
	return {};
}

function buildSafeError(error: unknown): IDataObject {
	if (!error || typeof error !== 'object') return { message: String(error) };
	const err = error as Record<string, unknown>;
	const safe: IDataObject = {};
	for (const key of ['message', 'description', 'httpCode', 'statusCode']) {
		if (err[key] !== undefined) safe[key] = err[key] as IDataObject[string];
	}
	if (err.response && typeof err.response === 'object') {
		const resp = err.response as Record<string, unknown>;
		safe.response = {
			statusCode: resp.statusCode ?? resp.status,
			body: typeof resp.body === 'object' ? (resp.body as IDataObject) : { rawBody: resp.body },
		};
	}
	return safe;
}

/**
 * Make an authenticated request to the Lead Management API using the
 * OAuth2 credential. Returns body + headers.
 */
export async function leadApiRequest(
	this: IExecuteFunctions | IHookFunctions | ILoadOptionsFunctions,
	method: IHttpRequestMethods,
	endpoint: string,
	body: IDataObject = {},
	qs: IDataObject = {},
): Promise<IApiResponse> {
	const baseUrl = this.getNodeParameter('baseUrl', 0) as string;
	if (!baseUrl) {
		throw new NodeApiError(this.getNode(), { message: 'Base URL is required' } as JsonObject);
	}

	const options: IHttpRequestOptions = {
		method,
		url: buildRequestUrl(baseUrl, endpoint),
		headers: {
			'Content-Type': 'application/json',
			Accept: 'application/json',
		},
		json: true,
		returnFullResponse: true,
	};

	if (Object.keys(body).length) options.body = body;
	if (Object.keys(qs).length) options.qs = qs;

	this.logger.debug(`Lead Management API Request: ${method} ${options.url}`);

	try {
		const response = await this.helpers.httpRequestWithAuthentication.call(
			this,
			'leadManagementOAuth2Api',
			options,
		);
		return {
			body: sanitizeBody(response as Record<string, unknown>),
			headers: sanitizeHeaders((response.headers ?? {}) as Record<string, unknown>),
		};
	} catch (error) {
		throw new NodeApiError(this.getNode(), buildSafeError(error) as JsonObject);
	}
}
