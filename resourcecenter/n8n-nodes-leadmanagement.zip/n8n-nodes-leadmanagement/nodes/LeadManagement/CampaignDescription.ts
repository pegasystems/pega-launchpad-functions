import type { INodeProperties } from 'n8n-workflow';

export const campaignOperations: INodeProperties[] = [
	{
		displayName: 'Operation',
		name: 'operation',
		type: 'options',
		noDataExpression: true,
		displayOptions: { show: { resource: ['campaign'] } },
		options: [
			{ name: 'Create', value: 'create', description: 'Create a new campaign', action: 'Create a campaign' },
			{ name: 'Delete', value: 'delete', description: 'Delete a campaign', action: 'Delete a campaign' },
		],
		default: 'create',
	},
];

const campShow = (operation: string) => ({
	show: { resource: ['campaign'], operation: [operation] },
});

export const campaignFields: INodeProperties[] = [
	// -------- campaign:create --------
	{ displayName: 'Name', name: 'name', type: 'string', required: true, default: '', displayOptions: campShow('create') },
	{
		displayName: 'Description',
		name: 'description',
		type: 'string',
		typeOptions: { rows: 3 },
		default: '',
		displayOptions: campShow('create'),
	},
	{ displayName: 'Start Date', name: 'startDate', type: 'dateTime', default: '', displayOptions: campShow('create') },
	{ displayName: 'End Date', name: 'endDate', type: 'dateTime', default: '', displayOptions: campShow('create') },
	{
		displayName: 'Channel',
		name: 'channel',
		type: 'options',
		default: 'email',
		options: [
			{ name: 'Email', value: 'email' },
			{ name: 'SMS', value: 'sms' },
			{ name: 'Social', value: 'social' },
			{ name: 'Web', value: 'web' },
		],
		displayOptions: campShow('create'),
	},
	{ displayName: 'Budget', name: 'budget', type: 'number', default: 0, displayOptions: campShow('create') },
	{ displayName: 'Target Audience', name: 'targetAudience', type: 'string', default: '', displayOptions: campShow('create') },

	// -------- campaign:delete --------
	{
		displayName: 'Campaign ID',
		name: 'campaignId',
		type: 'string',
		required: true,
		default: '',
		description: 'Unique identifier of the campaign',
		displayOptions: campShow('delete'),
	},
];
