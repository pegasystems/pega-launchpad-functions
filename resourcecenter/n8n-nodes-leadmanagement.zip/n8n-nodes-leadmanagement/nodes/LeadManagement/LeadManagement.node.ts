import type {
	IExecuteFunctions,
	IDataObject,
	INodeExecutionData,
	INodeType,
	INodeTypeDescription,
} from 'n8n-workflow';
import { NodeConnectionTypes, NodeOperationError } from 'n8n-workflow';

import { leadApiRequest, type IApiResponse } from './GenericFunctions';
import { leadOperations, leadFields } from './LeadDescription';
import { campaignOperations, campaignFields } from './CampaignDescription';
import { postOperations, postFields } from './PostDescription';

// ---------------------------------------------------------------------------
//  Resource handlers — each maps a node operation to a REST API call.
// ---------------------------------------------------------------------------

async function handleLead(
	ctx: IExecuteFunctions,
	operation: string,
	i: number,
): Promise<IApiResponse> {
	if (operation === 'create') {
		const body: IDataObject = {
			firstName: ctx.getNodeParameter('firstName', i) as string,
			lastName: ctx.getNodeParameter('lastName', i) as string,
			email: ctx.getNodeParameter('email', i) as string,
			phone: ctx.getNodeParameter('phone', i, '') as string,
			company: ctx.getNodeParameter('company', i, '') as string,
			jobTitle: ctx.getNodeParameter('jobTitle', i, '') as string,
			source: ctx.getNodeParameter('source', i) as string,
			rating: ctx.getNodeParameter('rating', i) as string,
			notes: ctx.getNodeParameter('notes', i, '') as string,
			status: 'new',
		};
		return await leadApiRequest.call(ctx, 'POST', '/api/leads', body);
	}

	if (operation === 'get') {
		const leadId = ctx.getNodeParameter('leadId', i) as string;
		return await leadApiRequest.call(ctx, 'GET', `/api/leads/${encodeURIComponent(leadId)}`);
	}

	if (operation === 'getStatus') {
		const leadId = ctx.getNodeParameter('leadId', i) as string;
		return await leadApiRequest.call(
			ctx,
			'GET',
			`/api/leads/${encodeURIComponent(leadId)}/status`,
		);
	}

	if (operation === 'getMany') {
		const limit = ctx.getNodeParameter('limit', i) as number;
		const filters = ctx.getNodeParameter('filters', i, {}) as IDataObject;
		const qs: IDataObject = { limit };
		if (filters.status) qs.status = filters.status;
		if (filters.source) qs.source = filters.source;
		if (filters.page) qs.page = filters.page;
		return await leadApiRequest.call(ctx, 'GET', '/api/leads', {}, qs);
	}

	if (operation === 'markInactive') {
		const leadId = ctx.getNodeParameter('leadId', i) as string;
		const reason = ctx.getNodeParameter('inactiveReason', i, '') as string;
		const body: IDataObject = { status: 'inactive' };
		if (reason) body.inactiveReason = reason;
		return await leadApiRequest.call(
			ctx,
			'PATCH',
			`/api/leads/${encodeURIComponent(leadId)}`,
			body,
		);
	}

	throw new NodeOperationError(ctx.getNode(), `Unsupported lead operation: ${operation}`);
}

async function handleCampaign(
	ctx: IExecuteFunctions,
	operation: string,
	i: number,
): Promise<IApiResponse> {
	if (operation === 'create') {
		const body: IDataObject = {
			name: ctx.getNodeParameter('name', i) as string,
			description: ctx.getNodeParameter('description', i, '') as string,
			startDate: ctx.getNodeParameter('startDate', i, '') as string,
			endDate: ctx.getNodeParameter('endDate', i, '') as string,
			channel: ctx.getNodeParameter('channel', i) as string,
			budget: ctx.getNodeParameter('budget', i, 0) as number,
			targetAudience: ctx.getNodeParameter('targetAudience', i, '') as string,
		};
		return await leadApiRequest.call(ctx, 'POST', '/api/campaigns', body);
	}

	if (operation === 'delete') {
		const campaignId = ctx.getNodeParameter('campaignId', i) as string;
		return await leadApiRequest.call(
			ctx,
			'DELETE',
			`/api/campaigns/${encodeURIComponent(campaignId)}`,
		);
	}

	throw new NodeOperationError(ctx.getNode(), `Unsupported campaign operation: ${operation}`);
}

async function handlePost(
	ctx: IExecuteFunctions,
	operation: string,
	i: number,
): Promise<IApiResponse> {
	if (operation === 'create') {
		const body: IDataObject = {
			title: ctx.getNodeParameter('title', i) as string,
			content: ctx.getNodeParameter('content', i) as string,
			campaignId: ctx.getNodeParameter('campaignId', i) as string,
			scheduledDate: ctx.getNodeParameter('scheduledDate', i, '') as string,
			platform: ctx.getNodeParameter('platform', i) as string,
		};
		return await leadApiRequest.call(ctx, 'POST', '/api/posts', body);
	}

	if (operation === 'getMany') {
		const limit = ctx.getNodeParameter('limit', i) as number;
		const filters = ctx.getNodeParameter('filters', i, {}) as IDataObject;
		const qs: IDataObject = { limit };
		if (filters.campaignId) qs.campaignId = filters.campaignId;
		if (filters.platform) qs.platform = filters.platform;
		if (filters.page) qs.page = filters.page;
		return await leadApiRequest.call(ctx, 'GET', '/api/posts', {}, qs);
	}

	throw new NodeOperationError(ctx.getNode(), `Unsupported post operation: ${operation}`);
}

const resourceHandlers: Record<
	string,
	(ctx: IExecuteFunctions, operation: string, i: number) => Promise<IApiResponse>
> = {
	lead: handleLead,
	campaign: handleCampaign,
	post: handlePost,
};

// ---------------------------------------------------------------------------
//  Node definition
// ---------------------------------------------------------------------------

export class LeadManagement implements INodeType {
	description: INodeTypeDescription = {
		displayName: 'Lead Management',
		name: 'leadManagement',
		icon: 'file:leadmanagement.svg',
		group: ['transform'],
		version: 1,
		subtitle: '={{$parameter["operation"] + ": " + $parameter["resource"]}}',
		description:
			'Example community node demonstrating Leads, Campaigns, and Posts against a generic REST API',
		defaults: { name: 'Lead Management' },
		usableAsTool: true,
		inputs: [NodeConnectionTypes.Main],
		outputs: [NodeConnectionTypes.Main],
		credentials: [{ name: 'leadManagementOAuth2Api', required: true }],
		properties: [
			{
				displayName: 'Base URL',
				name: 'baseUrl',
				type: 'string',
				required: true,
				default: '',
				placeholder: 'https://api.example.com',
				description: 'Base URL of your Lead Management API (no trailing slash)',
			},
			{
				displayName: 'Resource',
				name: 'resource',
				type: 'options',
				noDataExpression: true,
				options: [
					{ name: 'Lead', value: 'lead', description: 'A sales lead' },
					{ name: 'Campaign', value: 'campaign', description: 'A marketing campaign' },
					{ name: 'Post', value: 'post', description: 'A campaign post / activity' },
				],
				default: 'lead',
			},
			...leadOperations,
			...leadFields,
			...campaignOperations,
			...campaignFields,
			...postOperations,
			...postFields,
		],
	};

	async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
		const items = this.getInputData();
		const returnData: INodeExecutionData[] = [];

		const resource = this.getNodeParameter('resource', 0) as string;
		const operation = this.getNodeParameter('operation', 0) as string;

		this.logger.debug(
			`Running "Lead Management" node resource "${resource}" operation "${operation}"`,
		);

		const handler = resourceHandlers[resource];
		if (!handler) {
			throw new NodeOperationError(this.getNode(), `Unsupported resource: ${resource}`);
		}

		for (let i = 0; i < items.length; i++) {
			try {
				const responseData = await handler(this, operation, i);
				const executionData = this.helpers.constructExecutionMetaData(
					this.helpers.returnJsonArray({
						...responseData.body,
						responseHeaders: responseData.headers,
					}),
					{ itemData: { item: i } },
				);
				returnData.push(...executionData);
			} catch (error) {
				if (this.continueOnFail()) {
					returnData.push({
						json: { error: (error as Error).message },
						pairedItem: { item: i },
					});
					continue;
				}
				throw error;
			}
		}

		return [returnData];
	}
}
