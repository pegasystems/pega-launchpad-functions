const { src, dest, parallel } = require('gulp');

function copyIcons() {
	return src('nodes/**/*.svg').pipe(dest('dist/nodes'));
}

function copyCodex() {
	return src('nodes/**/*.node.json').pipe(dest('dist/nodes'));
}

function copyCredentialIcons() {
	return src('credentials/**/*.svg').pipe(dest('dist/credentials'));
}

exports['build:icons'] = parallel(copyIcons, copyCodex, copyCredentialIcons);
