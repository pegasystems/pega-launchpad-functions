# n8n-nodes-leadmanagement

An **example** [n8n](https://n8n.io/) community node — a small but complete reference for building a custom node that:

- Exposes **multiple resources** (Lead, Campaign, Post) with operation switches
- Uses **typed input fields** (string, number, options, dateTime, collection) instead of free-form JSON
- Authenticates via a **dedicated OAuth 2.0 (Client Credentials) credential**
- Wraps a **generic REST API** behind a clean helper function

It targets a hypothetical Lead Management REST API. Point it at any backend that exposes the endpoints listed below — or use it as a starting template and adapt the operations to your own service.

> This package is intentionally vendor-neutral. It is meant as a learning / template repository, not a production integration with any specific platform.

---

## Installation

Follow the [n8n community node installation guide](https://docs.n8n.io/integrations/community-nodes/installation/).

In your n8n instance: **Settings → Community Nodes → Install** → enter:

```
n8n-nodes-leadmanagement
```

Manual install:

```bash
npm install n8n-nodes-leadmanagement
```

## Operations

### Lead
| Operation | HTTP | Endpoint |
|---|---|---|
| Create | `POST` | `/api/leads` |
| Get | `GET` | `/api/leads/{id}` |
| Get Status | `GET` | `/api/leads/{id}/status` |
| Get Many | `GET` | `/api/leads?status=&source=&page=&limit=` |
| Mark Inactive | `PATCH` | `/api/leads/{id}` (body `{status: "inactive"}`) |

**Create Lead** exposes typed fields: First Name, Last Name, Email, Phone, Company, Job Title, Source (Web/Referral/Campaign/Cold Call/Event), Rating (Hot/Warm/Cold), Notes. The lead is created with `status: "new"`.

### Campaign
| Operation | HTTP | Endpoint |
|---|---|---|
| Create | `POST` | `/api/campaigns` |
| Delete | `DELETE` | `/api/campaigns/{id}` |

**Create Campaign** fields: Name, Description, Start Date, End Date, Channel (Email/SMS/Social/Web), Budget, Target Audience.

### Post
| Operation | HTTP | Endpoint |
|---|---|---|
| Create | `POST` | `/api/posts` |
| Get Many | `GET` | `/api/posts?campaignId=&platform=&page=&limit=` |

**Create Post** fields: Title, Content, Campaign ID (parent), Scheduled Date, Platform (Facebook/X/LinkedIn/Instagram).

## Credentials

The node uses an **OAuth 2.0 Client Credentials** flow via the **Lead Management OAuth2 API** credential.

Configure in n8n:

| Field | Example |
|---|---|
| Base URL | `https://api.example.com` |
| Access Token URL | `https://auth.example.com/oauth2/token` |
| Client ID | `your-client-id` |
| Client Secret | `your-client-secret` |
| Scope | _(optional, space-separated)_ |

The credential test hits `GET /api/health`. Adjust the test endpoint in [credentials/LeadManagementOAuth2Api.credentials.ts](credentials/LeadManagementOAuth2Api.credentials.ts) if your API uses a different health check.

## Compatibility

- n8n **≥ 1.0.0**
- Node.js **≥ 20**

## Development

```bash
npm install
npm run dev      # start n8n with this node hot-loaded
npm run build    # compile TypeScript + copy icons / codex JSON to dist/
npm run lint     # n8n-node lint (uses @n8n/node-cli/eslint config)
npm run lint:fix # auto-fix lint issues
```

## Project structure

```
n8n-nodes-leadmanagement/
├── credentials/
│   ├── LeadManagementOAuth2Api.credentials.ts   # OAuth2 (client credentials)
│   └── leadmanagement.svg
└── nodes/
    └── LeadManagement/
        ├── LeadManagement.node.ts               # main node + execute()
        ├── LeadManagement.node.json             # codex metadata
        ├── GenericFunctions.ts                  # authenticated REST helper
        ├── LeadDescription.ts                   # typed Lead fields
        ├── CampaignDescription.ts               # typed Campaign fields
        ├── PostDescription.ts                   # typed Post fields
        └── leadmanagement.svg                   # node icon
```

## How to adapt this template

- **Add a new operation** — add an option in `*Operations` (`LeadDescription.ts`), add its UI fields in `*Fields`, and add a branch in `handleLead/handleCampaign/handlePost` in [LeadManagement.node.ts](nodes/LeadManagement/LeadManagement.node.ts).
- **Add a new resource** — create a new `*Description.ts` file, register the resource in the `resource` options, spread its operations + fields into `properties`, and add a new handler function + entry in `resourceHandlers`.
- **Swap the auth flow** — replace `LeadManagementOAuth2Api.credentials.ts` with an API-key or basic-auth credential, and change the `'leadManagementOAuth2Api'` literal inside [GenericFunctions.ts](nodes/LeadManagement/GenericFunctions.ts).
- **Change the API shape** — all REST calls go through `leadApiRequest()` in [GenericFunctions.ts](nodes/LeadManagement/GenericFunctions.ts), so retries, custom headers, and pagination logic can be centralised there.

## License

[MIT](LICENSE)
