import type { ICredentialTestRequest, ICredentialType, INodeProperties } from 'n8n-workflow';

/**
 * Generic OAuth2 (Client Credentials) credential for the Lead Management
 * example node. Point `Base URL` and `Access Token URL` at your own backend.
 */
export class LeadManagementOAuth2Api implements ICredentialType {
	name = 'leadManagementOAuth2Api';

	extends = ['oAuth2Api'];

	displayName = 'Lead Management OAuth2 API';

	icon = 'file:leadmanagement.svg' as const;

	documentationUrl = 'https://oauth.net/2/grant-types/client-credentials/';

	// Lightweight connectivity check — adjust to a real endpoint your API exposes.
	test: ICredentialTestRequest = {
		request: {
			baseURL: '={{$credentials.baseUrl}}',
			url: '/api/health',
			method: 'GET',
		},
	};

	properties: INodeProperties[] = [
		{
			displayName: 'Base URL',
			name: 'baseUrl',
			type: 'string',
			default: '',
			placeholder: 'https://api.example.com',
			required: true,
			description: 'Base URL of your Lead Management API (no trailing slash)',
		},
		{
			displayName: 'Grant Type',
			name: 'grantType',
			type: 'hidden',
			default: 'clientCredentials',
		},
		{
			displayName: 'Access Token URL',
			name: 'accessTokenUrl',
			type: 'string',
			default: '',
			placeholder: 'https://auth.example.com/oauth2/token',
			required: true,
		},
		{
			displayName: 'Client ID',
			name: 'clientId',
			type: 'string',
			default: '',
			required: true,
		},
		{
			displayName: 'Client Secret',
			name: 'clientSecret',
			type: 'string',
			typeOptions: { password: true },
			default: '',
			required: true,
		},
		{
			displayName: 'Scope',
			name: 'scope',
			type: 'string',
			default: '',
			description: 'Optional OAuth2 scopes (space-separated)',
		},
		{
			displayName: 'Authentication',
			name: 'authentication',
			type: 'hidden',
			default: 'body',
		},
	];
}
