// This file exists only to satisfy the "main" field in package.json.
// n8n discovers the node and credential via the "n8n" section in package.json.
