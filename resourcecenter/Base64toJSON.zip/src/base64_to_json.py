import base64
import json


def handler(event, context) -> str:
    try:
        # Decode the Base64 string
        base64_input = event.get('base64_input',0)
        decoded_bytes = base64.b64decode(base64_input)
        decoded_string = decoded_bytes.decode('utf-8')

        # Split CSV into lines
        lines = decoded_string.strip().splitlines()
        if len(lines) < 2:
            raise ValueError("CSV must contain header and at least one row.")

        # Extract headers
        headers = [h.strip() for h in lines[0].split(",")]

        # Parse each row into a dictionary
        checklist = []
        for line in lines[1:]:
            values = [v.strip() for v in line.split(",")]
            obj = dict(zip(headers, values))
            checklist.append(obj)

        # Wrap into a final JSON object
        result_json = {"checklist": checklist}

        # Return the JSON as a string, pretty-printed
        return json.dumps({
            'statusCode': 200,
            'body': result_json
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})

