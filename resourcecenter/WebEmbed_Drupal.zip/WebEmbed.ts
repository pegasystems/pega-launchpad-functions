<html>
  <head>
    <script src="<SubscriberURL>/pega-static/pega-embed.js"></script>
  </head>
  <body>
    <div style="background-color: #cfcfcf; padding-left: 1rem; height: 3rem; line-height: 3rem; color: #ffffff;">
<div style="display: inline-block;"><svg style="fill: #3e67bb; height: 1rem; width: 1rem; vertical-align: middle;"role="presentation" class="sc-jlZhew jWDfaX" viewBox="0 0 25 25"><path d="m13.435 21.348-.144.144a1.27 1.27 0 0 1-.575.144c-.67 0-1.005-.335-1.005-.958 0-.144.096-.335.239-.67l5.987-8.19-6.035-8.285c-.143-.24-.191-.431-.191-.575 0-.623.335-.958 1.005-.958.192 0 .383.048.575.144l.144.143 6.8 8.86a.946.946 0 0 1 .288.671c0 .239-.096.431-.239.67l-6.848 8.86Zm-7.71 0-.145.144a1.27 1.27 0 0 1-.575.144c-.67 0-1.005-.335-1.005-.958 0-.144.096-.335.24-.67l5.986-8.19L4.19 3.533c-.142-.24-.19-.431-.19-.575C4 2.335 4.335 2 5.005 2c.192 0 .383.048.575.144l.144.143 6.801 8.86a.946.946 0 0 1 .287.671c0 .239-.096.431-.239.67l-6.848 8.86Z"></path></svg></div><a href="/LaunchpadSupport">Launchpad Support Home</a></div>
    <div id="theDiv"></div>
    <div id="testdata"></div>
    <script>

      const embedParams = {
        pegaServerUrl: '<SubscriberURL>',
        clientId: '<ClientID>',
        authorizeUri: '<AuthorizeURL>',      
        theme: '{"base":{"palette":{"brand-primary":"#24114B","foreground-color":"#5e4242","app-background":"#f3f3f3"}}}',
      };         

      function emitAttribIfPresent(attribName) {
        return embedParams[attribName] ? `${attribName}='${embedParams[attribName]}' ` : '';
      }

      function reloadList() {
         // const elEmbed = document.getElementById('odStore');
         // elEmbed.reload();
         // console.log("loaded: "+document.getElementById("odStore").getEmbedInfo());
      }

      function loadEmbed() {
        const elEmbed = document.getElementById('odStore');
        elEmbed.addEventListener('embedcaseclosed', reloadList);
        elEmbed.addEventListener('embedprocessingend', reloadList);
        elEmbed.addEventListener('embedeventcancel', reloadList);
        elEmbed.load();
      }

      function getEmbedMarkup() {
        return `<pega-embed id="odStore" action="openPage" pageID="<PageID>" ` +
        `pageClass="PegaPlatform__Data-Portal" autoReauth="true" casePage="full" assignmentHeader="false"  pegaServerType="launchpad" ` +
        `pegaServerUrl="${embedParams.pegaServerUrl}" grantType="authCode" ` +
        `clientId="${embedParams.clientId}" `+
        emitAttribIfPresent('clientSecret') +
        emitAttribIfPresent('redirectUri') +
        `authorizeUri="${embedParams.authorizeUri}"` +
        emitAttribIfPresent('tokenUri') +
        emitAttribIfPresent('staticContentUrl') +
        emitAttribIfPresent('theme') +
        'deferLoad="true" ' + 'resumeOnReload="false" ' +
        `style="width:100%"></pega-embed>`;
      }

      function updateEmbed() {
        document.getElementById("theDiv").innerHTML = getEmbedMarkup();
      }
      updateEmbed();
      loadEmbed();
    </script>
  </body>
</html>
