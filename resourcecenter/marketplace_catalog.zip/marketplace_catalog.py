"""
Launchpad Custom Function: AWS Marketplace Catalog API caller.

Runtime: Python 3.12 (AWS Lambda). boto3 is preinstalled in the runtime,
so the code bundle is just this single file (no dependencies to package).

Handler (set in the Function rule):
    marketplace_catalog.handler

Generic invoker: it can call any AWS Marketplace Catalog API operation
(start_change_set, describe_change_set, list_entities, ...) so the booster
never needs code changes - the Automation supplies the operation name and the
request parameters as a JSON string.

Inputs are read from the Lambda `event` by name (these must match the Custom
Function input names in the Function rule):
    - operation      : boto3 method name, e.g. "start_change_set"
    - request_json   : JSON string of the request params for that operation
    - access_key     : AWS access key id (AKIA... for a long-lived IAM user)
    - secret_key     : AWS secret access key
    - region         : AWS region (Marketplace Catalog is us-east-1 only)

Returns (Launchpad Lambda convention):
    {"statusCode": <int>, "body": <object>}
  where body on success is {"success": true, "data": <API response>}
  and on failure is {"success": false, "error": "...", "errorType": "..."}
"""

import json
import boto3


def _base_entity_id(identifier):
    """Return the stable entity ID required by DescribeEntity."""
    if not isinstance(identifier, str) or not identifier:
        raise ValueError("ChangeSet entity identifier must be a non-empty string")
    return identifier.split("@", 1)[0]


def _refresh_revisioned_entities(client, params):
    """Refresh product/offer revisions before release or visibility changes."""
    changes = params.get("ChangeSet")
    if not isinstance(changes, list):
        return params

    refresh_types = {"ReleaseProduct", "ReleaseOffer", "UpdateVisibility"}
    latest_by_base_id = {}
    for change in changes:
        if not isinstance(change, dict) or change.get("ChangeType") not in refresh_types:
            continue

        entity = change.get("Entity")
        if not isinstance(entity, dict):
            raise ValueError("A release or visibility change must include an Entity object")

        identifier = entity.get("Identifier")
        base_id = _base_entity_id(identifier)
        if base_id not in latest_by_base_id:
            described = client.describe_entity(
                Catalog="AWSMarketplace",
                EntityId=base_id,
            )
            latest_identifier = described.get("EntityIdentifier")
            if not latest_identifier:
                raise ValueError(f"DescribeEntity returned no EntityIdentifier for {base_id}")
            latest_by_base_id[base_id] = latest_identifier
        entity["Identifier"] = latest_by_base_id[base_id]

    return params


def handler(event, context):
    try:
        operation = event.get("operation", "")
        request_json = event.get("request_json", "") or ""
        access_key = event.get("access_key", "")
        secret_key = event.get("secret_key", "")
        region = event.get("region", "") or "us-east-1"

        if not operation or not isinstance(operation, str):
            return {
                "statusCode": 400,
                "body": {"success": False, "error": "No valid operation provided"},
            }
        if not access_key or not secret_key:
            return {
                "statusCode": 400,
                "body": {"success": False, "error": "Missing AWS credentials"},
            }

        params = json.loads(request_json) if request_json else {}
        if not isinstance(params, dict):
            return {
                "statusCode": 400,
                "body": {
                    "success": False,
                    "error": "request_json must be a JSON object of parameters",
                },
            }

        client = boto3.client(
            "marketplace-catalog",
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name=region,
        )

        if operation == "start_change_set":
            params = _refresh_revisioned_entities(client, params)

        method = getattr(client, operation, None)
        if method is None or not callable(method):
            return {
                "statusCode": 400,
                "body": {
                    "success": False,
                    "error": f"Unsupported operation: {operation}",
                },
            }

        response = method(**params)
        response.pop("ResponseMetadata", None)

        # json round-trip to coerce non-serializable types (e.g. datetime).
        data = json.loads(json.dumps(response, default=str))

        return {"statusCode": 200, "body": {"success": True, "data": data}}

    except Exception as exc:  # noqa: BLE001 - surface every failure to caller
        return {
            "statusCode": 500,
            "body": {
                "success": False,
                "error": str(exc),
                "errorType": type(exc).__name__,
            },
        }
