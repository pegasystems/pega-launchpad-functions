"""
Launchpad Custom Function: repair AWS Marketplace StartChangeSet body.

Runtime: Python 3.12 (AWS Lambda). Standard library only (json), so the code
bundle is just this single file (no dependencies to package).

Handler (set in the Function rule):
    repair_change_set_body.handler

Pure, side-effect-free JSON transformation - no network calls, no AWS SDK,
no shared state. Its job is to convert each dimension change's DetailsDocument
from the object form {"Dimensions": [ ... ]} into the bare array [ ... ] that
the Catalog API requires, and to strip the @<revision> suffix from a
CreateOffer ProductId. Every dimension is built correctly upstream (Launchpad
automation + JSONTransform), so each dimension dict - including its Types and
Unit - is preserved verbatim. All other change types (CreateOffer,
UpdateInformation, UpdatePricingTerms) keep their DetailsDocument dict as-is.
ChangeType and ChangeName are both set upstream and are left untouched.

Inputs are read from the Lambda `event` by name (these must match the Custom
Function input names in the Function rule):
    - request_json   : JSON string of the StartChangeSet request body

Returns:
    The corrected StartChangeSet request body as a compact JSON string.
    On failure, raises the underlying exception (e.g. ValueError for bad JSON).
"""

import json


def _extract_dimensions(details_document):
    """Extract the bare list of dimension objects from a DetailsDocument.

    Supports both the object form {"Dimensions": [...]} and an already-bare
    list. Each dimension dict is returned as-is (not rebuilt), so Types, Unit,
    and any other upstream-computed keys are preserved verbatim.
    """
    if isinstance(details_document, list):
        return details_document
    if isinstance(details_document, dict):
        dims = details_document.get("Dimensions")
        if isinstance(dims, list):
            return dims
        return []
    return []


def _is_offer(change):
    """True when the change targets an Offer entity (Entity.Type == Offer@...).

    Used to tell an Offer's UpdateInformation ({Name, Description}) apart from a
    SaaSProduct's UpdateInformation (product listing fields).
    """
    entity = change.get("Entity")
    entity_type = entity.get("Type") if isinstance(entity, dict) else None
    return isinstance(entity_type, str) and entity_type.startswith("Offer@")


def _strip_revision(identifier):
    """Strip a trailing @<revision> from a product id.

    Leaves change-set references (e.g. "$CreateProductChange.Entity.Identifier")
    and non-string values untouched.
    """
    if isinstance(identifier, str) and not identifier.startswith("$") and "@" in identifier:
        return identifier.split("@", 1)[0]
    return identifier


def repair(request_json: str) -> str:
    """Repair an AWS Marketplace StartChangeSet request body.

    Args:
        request_json: JSON string of the StartChangeSet request body.

    Returns:
        Corrected request body as a compact JSON string.

    Raises:
        ValueError: if the input cannot be parsed as JSON.
    """
    try:
        body = json.loads(request_json)
    except (ValueError, TypeError) as exc:
        raise ValueError(f"Invalid request_json: could not parse JSON ({exc})")

    change_set = body.get("ChangeSet") if isinstance(body, dict) else None
    if not isinstance(change_set, list):
        return json.dumps(body)

    filtered = []
    for change in change_set:
        if not isinstance(change, dict):
            filtered.append(change)
            continue

        change_type = change.get("ChangeType")

        if change_type in ("UpdateDimensions", "AddDimensions"):
            # Normalize DetailsDocument to a bare list. If the result is empty,
            # drop the entire change — AWS requires at least 1 element and
            # rejects an empty array with a ValidationException.
            dims = _extract_dimensions(change.get("DetailsDocument"))
            if not dims:
                continue
            change["DetailsDocument"] = dims

        elif change_type == "UpdateInformation":
            # DetailsDocument stays a dict. For an Offer the body is
            # {Name, Description} and must be preserved verbatim. Only a
            # SaaSProduct's listing body may carry a stray Dimensions key to
            # strip.
            details = change.get("DetailsDocument")
            if not _is_offer(change) and isinstance(details, dict):
                details.pop("Dimensions", None)

        elif change_type == "CreateOffer":
            # ProductId must be the bare product id - the @<revision> suffix
            # fails the CreateOffer schema regex.
            details = change.get("DetailsDocument")
            if isinstance(details, dict) and "ProductId" in details:
                details["ProductId"] = _strip_revision(details["ProductId"])

        elif change_type == "UpdatePricingTerms":
            # Drop the change if Terms is missing, empty, or every term has no
            # RateCards — an incomplete pricing change fails AWS validation and
            # is meaningless for a free product.
            details = change.get("DetailsDocument")
            terms = details.get("Terms") if isinstance(details, dict) else None
            if not isinstance(terms, list) or not terms:
                continue
            has_rate_cards = any(
                isinstance(t, dict) and t.get("RateCards")
                for t in terms
            )
            if not has_rate_cards:
                continue

        elif change_type in ("ReleaseProduct", "ReleaseOffer"):
            # AWS requires Details or DetailsDocument to be present even for
            # release changes. Inject an empty dict if neither is provided.
            if "DetailsDocument" not in change and "Details" not in change:
                change["DetailsDocument"] = {}

        # All other change types keep their DetailsDocument dict verbatim.

        filtered.append(change)

    body["ChangeSet"] = filtered
    return json.dumps(body)


def handler(event, context):
    request_json = event.get("request_json", "") or ""

    if not request_json or not isinstance(request_json, str):
        raise ValueError("No valid request_json provided")

    return repair(request_json)


if __name__ == "__main__":
    sample = {
        "Catalog": "AWSMarketplace",
        "ChangeSet": [
            {
                "ChangeType": "UpdateInformation",
                "ChangeName": "UpdateInformationChange",
                "Entity": {"Type": "SaaSProduct@1.0", "Identifier": "prod-abc"},
                "DetailsDocument": {
                    "ProductTitle": "My Product",
                    "ShortDescription": "Short",
                    "LongDescription": "Long",
                    "SupportDescription": "Support",
                    "LogoUrl": "https://example.com/logo.png",
                    "Highlights": ["a", "b"],
                    "SearchKeywords": ["k1"],
                    "Categories": ["Cat1"],
                    "Dimensions": [{"Key": "stray", "Name": "stray"}],
                },
            },
            {
                # Contract product -> Types must stay ["Entitled"], Unit kept
                "ChangeType": "UpdateDimensions",
                "ChangeName": "UpdateDimensionsChange",
                "Entity": {"Type": "SaaSProduct@1.0", "Identifier": "prod-abc"},
                "DetailsDocument": {
                    "Dimensions": [
                        {
                            "Key": "seats",
                            "Name": "Seats",
                            "Description": "Per seat",
                            "Unit": "Users",
                            "Types": ["Entitled"],
                        }
                    ]
                },
            },
            {
                "ChangeType": "CreateOffer",
                "ChangeName": "CreateOfferChange",
                "Entity": {"Type": "Offer@1.0", "Identifier": ""},
                "DetailsDocument": {"Name": "Offer"},
            },
        ],
    }

    result = handler({"request_json": json.dumps(sample)}, None)

    ok = True
    try:
        out = json.loads(result)
        cs = out["ChangeSet"]

        # ChangeSet[1] is UpdateDimensions -> bare list, ChangeType preserved,
        # Types and Unit preserved verbatim from the input.
        assert cs[1]["ChangeType"] == "UpdateDimensions", "ChangeType not preserved"
        assert cs[1]["ChangeName"] == "UpdateDimensionsChange", "ChangeName wrong"
        assert isinstance(cs[1]["DetailsDocument"], list), "DetailsDocument not list"
        udim = cs[1]["DetailsDocument"][0]
        assert udim == {
            "Key": "seats",
            "Name": "Seats",
            "Description": "Per seat",
            "Unit": "Users",
            "Types": ["Entitled"],
        }, f"UpdateDimensions dimension not preserved verbatim: {udim}"
        assert udim["Types"] == ["Entitled"], "Types not preserved (Entitled)"
        assert udim["Unit"] == "Users", "Unit not preserved"

        ui = cs[0]["DetailsDocument"]
        assert isinstance(ui, dict), "UpdateInformation DetailsDocument not a dict"
        assert "Dimensions" not in ui, "stray Dimensions not removed"

        assert cs[2]["ChangeType"] == "CreateOffer", "CreateOffer changed"
        assert cs[2]["DetailsDocument"] == {"Name": "Offer"}, "CreateOffer body changed"

        # AddDimensions -> bare list; Subscription Types + custom Unit preserved.
        add_in = {
            "Catalog": "AWSMarketplace",
            "ChangeSet": [
                {
                    "ChangeType": "AddDimensions",
                    "ChangeName": "x",
                    "Entity": {"Type": "SaaSProduct@1.0", "Identifier": "prod-abc"},
                    "DetailsDocument": {
                        "Dimensions": [
                            {
                                "Key": "api_calls",
                                "Name": "API Calls",
                                "Description": "Per 1000 calls",
                                "Unit": "Requests",
                                "Types": ["Metered", "ExternallyMetered"],
                            }
                        ]
                    },
                }
            ],
        }
        add_out = json.loads(handler({"request_json": json.dumps(add_in)}, None))
        add_change = add_out["ChangeSet"][0]
        assert add_change["ChangeType"] == "AddDimensions", "AddDimensions not preserved"
        assert add_change["ChangeName"] == "x", "ChangeName should be left untouched"
        assert isinstance(add_change["DetailsDocument"], list), "DetailsDocument not list"
        add_dim = add_change["DetailsDocument"][0]
        assert add_dim == {
            "Key": "api_calls",
            "Name": "API Calls",
            "Description": "Per 1000 calls",
            "Unit": "Requests",
            "Types": ["Metered", "ExternallyMetered"],
        }, f"AddDimensions dimension not preserved verbatim: {add_dim}"
        assert add_dim["Types"] == ["Metered", "ExternallyMetered"], "Types not preserved"
        assert add_dim["Unit"] == "Requests", "Unit not preserved (forced to Units?)"

        # Already-bare list input is passed through unchanged.
        bare_in = {
            "Catalog": "AWSMarketplace",
            "ChangeSet": [
                {"ChangeType": "AddDimensions", "ChangeName": "x", "Entity": {},
                 "DetailsDocument": [
                     {"Key": "k", "Name": "n", "Description": "d",
                      "Unit": "GB", "Types": ["Entitled"]}
                 ]}
            ],
        }
        bare_out = json.loads(handler({"request_json": json.dumps(bare_in)}, None))
        assert bare_out["ChangeSet"][0]["DetailsDocument"] == [
            {"Key": "k", "Name": "n", "Description": "d",
             "Unit": "GB", "Types": ["Entitled"]}
        ], "bare list not preserved"

        # Empty / missing dimensions -> entire change is dropped from ChangeSet
        # (AWS rejects an empty array with ValidationException).
        empty_in = {
            "Catalog": "AWSMarketplace",
            "ChangeSet": [
                {"ChangeType": "UpdateDimensions", "ChangeName": "x",
                 "Entity": {}, "DetailsDocument": None}
            ],
        }
        empty_data = json.loads(handler({"request_json": json.dumps(empty_in)}, None))
        assert empty_data["ChangeSet"] == [], "empty-dims change should be dropped"

        # UpdatePricingTerms with no RateCards -> dropped (free product path).
        free_in = {
            "Catalog": "AWSMarketplace",
            "ChangeSet": [
                {"ChangeType": "CreateOffer", "ChangeName": "CreateOfferChange",
                 "Entity": {"Type": "Offer@1.0"},
                 "DetailsDocument": {"ProductId": "prod-abc"}},
                {"ChangeType": "UpdatePricingTerms", "ChangeName": "UpdatePricingTermsChange",
                 "Entity": {"Type": "Offer@1.0", "Identifier": "$CreateOfferChange.Entity.Identifier"},
                 "DetailsDocument": {"PricingModel": "Usage",
                                     "Terms": [{"Type": "UsageBasedPricingTerm", "CurrencyCode": "USD"}]}},
            ],
        }
        free_out = json.loads(handler({"request_json": json.dumps(free_in)}, None))
        assert len(free_out["ChangeSet"]) == 1, "UpdatePricingTerms with no RateCards should be dropped"
        assert free_out["ChangeSet"][0]["ChangeType"] == "CreateOffer", "CreateOffer should remain"

        # ReleaseProduct / ReleaseOffer without DetailsDocument -> {} injected.
        release_in = {
            "Catalog": "AWSMarketplace",
            "ChangeSet": [
                {"ChangeType": "ReleaseProduct", "ChangeName": "ReleaseProductChange",
                 "Entity": {"Type": "SaaSProduct@1.0", "Identifier": "prod-abc@1"}},
                {"ChangeType": "ReleaseOffer", "ChangeName": "ReleaseOfferChange",
                 "Entity": {"Type": "Offer@1.0", "Identifier": "offer-xyz@1"}},
            ],
        }
        release_out = json.loads(handler({"request_json": json.dumps(release_in)}, None))
        assert release_out["ChangeSet"][0]["DetailsDocument"] == {}, \
            "ReleaseProduct should have DetailsDocument injected"
        assert release_out["ChangeSet"][1]["DetailsDocument"] == {}, \
            "ReleaseOffer should have DetailsDocument injected"
        # If DetailsDocument already present, leave it untouched.
        release_existing = {
            "Catalog": "AWSMarketplace",
            "ChangeSet": [
                {"ChangeType": "ReleaseProduct", "ChangeName": "ReleaseProductChange",
                 "Entity": {"Type": "SaaSProduct@1.0", "Identifier": "prod-abc@1"},
                 "DetailsDocument": {"Key": "value"}},
            ],
        }
        release_existing_out = json.loads(handler({"request_json": json.dumps(release_existing)}, None))
        assert release_existing_out["ChangeSet"][0]["DetailsDocument"] == {"Key": "value"}, \
            "existing DetailsDocument on ReleaseProduct should not be overwritten"

        # CreateOffer ProductId: @<revision> stripped; $refs untouched.
        offer_in = {
            "Catalog": "AWSMarketplace",
            "ChangeSet": [
                {"ChangeType": "CreateOffer", "ChangeName": "CreateOfferChange",
                 "Entity": {"Type": "Offer@1.0"},
                 "DetailsDocument": {"ProductId": "prod-exodfot2wf3sw@1"}},
                {"ChangeType": "CreateOffer", "ChangeName": "c2",
                 "Entity": {"Type": "Offer@1.0"},
                 "DetailsDocument": {"ProductId": "$CreateProductChange.Entity.Identifier"}},
            ],
        }
        offer_out = json.loads(handler({"request_json": json.dumps(offer_in)}, None))
        assert offer_out["ChangeSet"][0]["DetailsDocument"]["ProductId"] == "prod-exodfot2wf3sw", \
            "ProductId revision not stripped"
        assert offer_out["ChangeSet"][1]["DetailsDocument"]["ProductId"] == "$CreateProductChange.Entity.Identifier", \
            "ProductId reference should be untouched"

        # Offer UpdateInformation ({Name, Description}) is preserved verbatim -
        # no Dimensions pop, dict shape kept, ChangeName untouched. Plus a full
        # Usage + Contract pricing bundle passes through unchanged.
        bundle_in = {
            "Catalog": "AWSMarketplace",
            "ChangeSet": [
                {"ChangeType": "UpdateInformation",
                 "ChangeName": "UpdateOfferInformationChange",
                 "Entity": {"Type": "Offer@1.0",
                            "Identifier": "$CreateOfferChange.Entity.Identifier"},
                 "DetailsDocument": {"Name": "Public Offer",
                                     "Description": "Public offer with usage pricing"}},
                {"ChangeType": "UpdatePricingTerms",
                 "ChangeName": "UpdatePricingTermsChange",
                 "Entity": {"Type": "Offer@1.0",
                            "Identifier": "$CreateOfferChange.Entity.Identifier"},
                 "DetailsDocument": {
                     "PricingModel": "Contract",
                     "Terms": [
                         {"Type": "ConfigurableUpfrontPricingTerm",
                          "CurrencyCode": "USD",
                          "RateCards": [
                              {"Selector": {"Type": "Duration", "Value": "P12M"},
                               "RateCard": [
                                   {"DimensionKey": "api_calls", "Price": "1000"},
                                   {"DimensionKey": "active_users", "Price": "500"}],
                               "Constraints": {"MultipleDimensionSelection": "Allowed",
                                               "QuantityConfiguration": "Allowed"}}]}]}},
            ],
        }
        bundle_out = json.loads(handler({"request_json": json.dumps(bundle_in)}, None))
        offer_ui = bundle_out["ChangeSet"][0]
        assert offer_ui["ChangeName"] == "UpdateOfferInformationChange", \
            "Offer UpdateInformation ChangeName should be untouched"
        assert offer_ui["DetailsDocument"] == {
            "Name": "Public Offer",
            "Description": "Public offer with usage pricing",
        }, "Offer UpdateInformation body not preserved verbatim"
        pricing = bundle_out["ChangeSet"][1]
        assert pricing["DetailsDocument"] == bundle_in["ChangeSet"][1]["DetailsDocument"], \
            "UpdatePricingTerms body not preserved verbatim"

        # Bad JSON -> raises ValueError
        try:
            handler({"request_json": "{not json"}, None)
            raise AssertionError("expected ValueError for bad JSON")
        except ValueError:
            pass

        # Missing request_json -> raises ValueError
        try:
            handler({}, None)
            raise AssertionError("expected ValueError for missing request_json")
        except ValueError:
            pass
    except AssertionError as err:
        ok = False
        print(f"FAIL: {err}")

    if ok:
        print("PASS")
