const REPLACE_DOMAIN = "https://isv-useast1-prod.pega.net/prweb/PRAuth/launchpath?";

function replaceDomain() {
    console.log("replaceDomain called");

    chrome.storage.sync.get('providerDomain', function(data) {
        const customDomain = data.providerDomain || 'launchpad.io';

        // Get all anchor tags on the main document
        const links = document.getElementsByTagName('a');
        console.log("Number of links found on the main document:", links.length);

        for (let link of links) {
            if (link.href.toLowerCase().includes(REPLACE_DOMAIN.toLowerCase())) {
                console.log("Replacing domain in link:", link.href);
                link.href = link.href.replace(REPLACE_DOMAIN, customDomain);
                console.log("Updated link:", link.href);
            }
        }

    });
}


// Observer to detect and handle dynamically added content
const observer = new MutationObserver((mutationsList) => {
    for (let mutation of mutationsList) {
        if (mutation.type === 'childList') {
            console.log("DOM modified, re-running replaceDomain");
            replaceDomain(); // Re-run replaceDomain for newly added links
        }
    }
});

// Start observing the document's body for changes
observer.observe(document.body, { childList: true, subtree: true });

// Initial call to replace links already on the page
replaceDomain();