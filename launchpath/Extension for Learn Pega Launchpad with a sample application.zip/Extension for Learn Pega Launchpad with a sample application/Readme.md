# Fast Track Chrome Extension

This extension is a prototype.  It is designed to swap out the URL to Civic Sync to a provider specific URL so that providers can reference a local reference application installed in their provider.

## Installation (for testing)

* Go to [chrome://extensions](chrome://extensions) in your browser.
* Enable Developer Mode
* Click "Load Unpacked"
* Select This Folder
* Click the Details button for the extension
* Update the destination URL

