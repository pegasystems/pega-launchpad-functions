// Save the domain to Chrome's storage API
function saveOptions() {
    const domain = document.getElementById('providerDomain').value;
    chrome.storage.sync.set({providerDomain: domain}, function() {
        console.log('Domain is set to ' + domain);
    });
}

// Load the domain when the options page is opened
function restoreOptions() {
    chrome.storage.sync.get('providerDomain', function(items) {
        document.getElementById('providerDomain').value = items.providerDomain || '';
    });
}

document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('domainForm').addEventListener('submit', function(event) {
    event.preventDefault();
    saveOptions();
});
